package parser;

/** Acts as a pointer to an int value. */
public class IntPointer {
	public int value;
}
