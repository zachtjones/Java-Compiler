package tokens;

public interface Token {

}
