package tokens.assignment;

import tokens.Token;

public class NotEqualsToken implements Token {
private NotEqualsToken() {}
	
	private static NotEqualsToken instance = new NotEqualsToken();
	
	public static NotEqualsToken getInstance() {
		return instance;
	}
}
