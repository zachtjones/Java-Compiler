package declarations;
/**
 * Instances of this are Assignment, IfStatement, WhileStatement, DoWhileStatement, SwitchStatement, ...
 */
public interface Statement {

}
