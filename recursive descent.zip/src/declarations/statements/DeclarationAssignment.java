package declarations.statements;

import declarations.ArgType;
import declarations.Statement;

public class DeclarationAssignment implements Statement {
	public ArgType type;
	public String name;
	public Expression assingment;
}
