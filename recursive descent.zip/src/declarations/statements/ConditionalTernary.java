package declarations.statements;

/** Represents a ? : statement in java */
public class ConditionalTernary implements Expression {
	public Expression condition;
	public Expression truePart;
	public Expression falsePart;
}
