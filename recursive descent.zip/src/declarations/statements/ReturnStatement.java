package declarations.statements;

import declarations.Statement;

public class ReturnStatement implements Statement {
	public Expression expression; // could be null for return;
}
