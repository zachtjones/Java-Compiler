package declarations.statements;

import declarations.Statement;

public interface Expression extends Statement { // expressions are a specific type of statement

}
