package declarations.statements;

import declarations.ArgType;
import declarations.Statement;

public class Declaration implements Statement {
	public ArgType type;
	public String name;
}
