package declarations.statements;

import declarations.Statement;

public class Assignment implements Statement {
	public String name;
	public Expression assingment;
}
