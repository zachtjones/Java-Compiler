package declarations.statements;

import tokens.Token;

public class BinaryExpression implements Expression {
	public Expression left;
	public Token operator;
	public Expression right;
}
