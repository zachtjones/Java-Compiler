package declarations;

public class VariableDeclaration {
	public ArgType type;
	public String name;
}
