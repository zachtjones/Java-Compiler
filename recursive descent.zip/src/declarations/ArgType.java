package declarations;

/**
 * Either a return value, or parameter. This is either a KeywordToken or ClassToken instance.
 */
public interface ArgType {}
