package declarations;

public class InterfaceDeclaration {

}
