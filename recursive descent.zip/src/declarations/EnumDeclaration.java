package declarations;

public class EnumDeclaration {

}
